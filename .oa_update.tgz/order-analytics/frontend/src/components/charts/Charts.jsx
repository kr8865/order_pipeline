/* Chart components (Recharts). Each one is reusable: data + callbacks come in through props. */
import {
  Area, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Line, LineChart, Pie, PieChart, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { formatMoney, formatNumber, formatPeriod, SERIES, STATUS_COLORS } from '../../utils/format'

const axis = { fontSize: 12, fill: '#94a3b8' }
const grid = <CartesianGrid strokeDasharray="3 3" stroke="#eef2f7" vertical={false} />
const tooltipStyle = { borderRadius: 10, border: '1px solid #e2e8f0', boxShadow: '0 8px 24px rgba(15,23,42,.08)', fontSize: 13 }

/** Tiny chart inside a KPI card. */
export function Sparkline({ data, dataKey, color, type = 'line' }) {
  if (!data?.length) return null
  return (
    <ResponsiveContainer width="100%" height={42}>
      {type === 'bar' ? (
        <BarChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
          <Bar dataKey={dataKey} fill={color} radius={[3, 3, 0, 0]} isAnimationActive={false} />
        </BarChart>
      ) : (
        <LineChart data={data} margin={{ top: 4, right: 2, left: 2, bottom: 4 }}>
          <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} />
        </LineChart>
      )}
    </ResponsiveContainer>
  )
}

/**
 * Revenue trend: bars = orders, smooth line/area = revenue (like the "Website Visits" chart in the brief).
 * `view` is 'both' | 'revenue' | 'orders' (the Revenue vs Orders toggle).
 */
export function RevenueTrendChart({ data, view, currency, granularity, onPointClick }) {
  const showRevenue = view !== 'orders'
  const showOrders = view !== 'revenue'
  return (
    <ResponsiveContainer width="100%" height={300}>
      <ComposedChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}
        onClick={(e) => e?.activePayload && onPointClick?.(e.activePayload[0].payload)}
        style={{ cursor: onPointClick ? 'pointer' : 'default' }}>
        <defs>
          <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.28} />
            <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        {grid}
        <XAxis dataKey="period" tick={axis} tickFormatter={(v) => formatPeriod(v, granularity)} minTickGap={18} axisLine={false} tickLine={false} />
        {showRevenue && (
          <YAxis yAxisId="rev" tick={axis} width={70} axisLine={false} tickLine={false}
            tickFormatter={(v) => formatMoney(v, currency, { compact: true })} />
        )}
        {showOrders && (
          <YAxis yAxisId="ord" orientation={showRevenue ? 'right' : 'left'} tick={axis} width={40}
            allowDecimals={false} axisLine={false} tickLine={false} />
        )}
        <Tooltip contentStyle={tooltipStyle}
          labelFormatter={(v) => `${granularity === 'day' ? '' : granularity === 'week' ? 'Week of ' : ''}${formatPeriod(v, granularity === 'month' ? 'month' : 'day')}`}
          formatter={(v, name) => (name === 'Revenue' ? [formatMoney(v, currency), name] : [formatNumber(v), name])} />
        {showOrders && (
          <Bar yAxisId="ord" dataKey="orders" name="Orders" fill="#3b82f6" barSize={data.length > 40 ? 4 : 10} radius={[4, 4, 0, 0]} />
        )}
        {showRevenue && (
          <Area yAxisId="rev" type="monotone" dataKey="revenue" name="Revenue" stroke="#f59e0b" strokeWidth={2.5}
            fill="url(#revFill)" dot={false} activeDot={{ r: 5 }} />
        )}
      </ComposedChart>
    </ResponsiveContainer>
  )
}

/** Category share donut (like "Current Visits"). Click a slice to drill down. */
export function CategoryDonut({ data, metric, currency, selected = [], onSliceClick }) {
  const key = metric === 'orders' ? 'orders' : 'revenue'
  const total = data.reduce((s, d) => s + d[key], 0)
  return (
    <div className="donut-wrap">
      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie data={data} dataKey={key} nameKey="category" innerRadius={58} outerRadius={92} paddingAngle={2}
            onClick={(d) => onSliceClick?.(d.category)} style={{ cursor: 'pointer' }}>
            {data.map((d, i) => (
              <Cell key={d.category} fill={SERIES[i % SERIES.length]}
                fillOpacity={selected.length && !selected.includes(d.category) ? 0.3 : 1} />
            ))}
          </Pie>
          <Tooltip contentStyle={tooltipStyle}
            formatter={(v, n) => [key === 'revenue' ? formatMoney(v, currency) : `${v} orders`, n]} />
        </PieChart>
      </ResponsiveContainer>
      <div className="donut-center">
        <span className="muted tiny">{key === 'revenue' ? 'Revenue' : 'Orders'}</span>
        <strong>{key === 'revenue' ? formatMoney(total, currency, { compact: true }) : formatNumber(total)}</strong>
      </div>
      <ul className="legend-list">
        {data.map((d, i) => (
          <li key={d.category}>
            <button onClick={() => onSliceClick?.(d.category)} title={`Drill into ${d.category}`}>
              <span className="dot" style={{ background: SERIES[i % SERIES.length] }} />
              <span className="legend-name">{d.category}</span>
              <span className="legend-val">{key === 'revenue' ? `${d.share}%` : d.orders}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

const STACK = ['Delivered', 'In Transit', 'Pending', 'Delayed']

/** Orders per period stacked by delivery outcome (like the "Visitors / Sales" stacked bars). */
export function DeliveryStackedChart({ data, granularity, onBarClick }) {
  const rows = data.map((d) => ({ period: d.period, ...d.by_status }))
  const present = STACK.filter((s) => rows.some((r) => r[s]))
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={rows} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
        {grid}
        <XAxis dataKey="period" tick={axis} tickFormatter={(v) => formatPeriod(v, granularity)} minTickGap={18} axisLine={false} tickLine={false} />
        <YAxis tick={axis} allowDecimals={false} width={36} axisLine={false} tickLine={false} />
        <Tooltip contentStyle={tooltipStyle} labelFormatter={(v) => formatPeriod(v, 'day')} cursor={{ fill: '#f1f5f9' }} />
        {present.map((s, i) => (
          <Bar key={s} dataKey={s} stackId="a" fill={STATUS_COLORS[s]} barSize={rows.length > 40 ? 6 : 18}
            radius={i === present.length - 1 ? [4, 4, 0, 0] : 0}
            onClick={() => onBarClick?.(s)} style={{ cursor: 'pointer' }} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  )
}

export function DeliveryDaysChart({ data, sla }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 16, right: 8, left: 0, bottom: 0 }}>
        {grid}
        <XAxis dataKey="days" tick={axis} axisLine={false} tickLine={false}
          label={{ value: 'days to deliver', position: 'insideBottom', offset: -2, fontSize: 11, fill: '#94a3b8' }} height={34} />
        <YAxis tick={axis} allowDecimals={false} width={32} axisLine={false} tickLine={false} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v} orders`, 'Orders']} labelFormatter={(d) => `${d} day(s)`} />
        <ReferenceLine x={sla} stroke="#ef4444" strokeDasharray="4 4" label={{ value: `SLA ${sla}d`, fill: '#ef4444', fontSize: 11, position: 'top' }} />
        <Bar dataKey="orders" radius={[5, 5, 0, 0]}>
          {data.map((d) => <Cell key={d.days} fill={d.late ? '#ef4444' : '#10b981'} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
