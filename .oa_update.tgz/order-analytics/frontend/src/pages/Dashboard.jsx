import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import FilterBar from '../components/FilterBar'
import { CategoryDrilldown } from '../components/Drilldowns'
import {
  CategoryDonut, DeliveryDaysChart, DeliveryStackedChart, RevenueTrendChart, Sparkline,
} from '../components/charts/Charts'
import { IconCart, IconClock, IconRupee, IconShield, IconTruck } from '../components/icons'
import { Card, EmptyState, ErrorState, KpiCard, Segmented, Skeleton, StatusBadge } from '../components/ui'
import { errorMessage, filterParams, useGetDataQualityQuery, useGetSummaryQuery } from '../services/api'
import {
  activeFilterCount, resetFilters, selectFilters, setDateRange, setGranularity, setMetric, toggleStatus,
} from '../features/filters/filtersSlice'
import { formatMoney, formatNumber, periodEnd } from '../utils/format'

const VIEWS = [{ value: 'both', label: 'Both' }, { value: 'revenue', label: 'Revenue' }, { value: 'orders', label: 'Orders' }]
const SHARE = [{ value: 'revenue', label: 'Revenue' }, { value: 'orders', label: 'Orders' }]
const GRANULARITY = [
  { value: 'auto', label: 'Auto' }, { value: 'day', label: 'Daily' }, { value: 'week', label: 'Weekly' }, { value: 'month', label: 'Monthly' },
]

function greeting() {
  const h = new Date().getHours()
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'
}

export default function Dashboard() {
  const f = useSelector(selectFilters)
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [drillCategory, setDrillCategory] = useState(null)
  const [shareMetric, setShareMetric] = useState('revenue')
  const invalidRange = f.startDate && f.endDate && f.startDate > f.endDate
  const { data, error, isLoading, isFetching, refetch } = useGetSummaryQuery(
    filterParams(f, { granularity: f.granularity }), { skip: invalidRange },
  )
  const { data: quality } = useGetDataQualityQuery()
  const cur = data?.currency?.code || f.currency
  const k = data?.kpis
  const change = data?.comparison?.change_pct ?? {}
  const gran = data?.filters?.granularity || 'day'
  const trend = data?.revenue_trend ?? []
  const view = ['both', 'revenue', 'orders'].includes(f.metric) ? f.metric : 'both'
  const issues = quality?.checks.filter((c) => c.count > 0) ?? []

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{greeting()}, welcome back</h1>
          <p className="muted">
            Orders, revenue and delivery performance
            {data?.comparison && <> · compared with {data.comparison.previous_start} → {data.comparison.previous_end}</>}
            {data?.currency?.source === 'fallback' &&
              <span className="pill warn" title="Live FX API unreachable — using approximate rates">approx. FX rates</span>}
          </p>
        </div>
        {isFetching && !isLoading && <span className="muted small"><span className="spinner sm" /> Updating…</span>}
      </div>

      <FilterBar />

      {error ? <ErrorState message={errorMessage(error)} onRetry={refetch} /> : (
        <>
          {/* ---------- KPI cards ---------- */}
          <div className={`kpi-grid ${isFetching ? 'dim' : ''}`}>
            {isLoading ? [1, 2, 3, 4].map((i) => <Skeleton key={i} height={170} />) : (
              <>
                <KpiCard color="blue" icon={<IconCart />} label="Total Orders" value={formatNumber(k.total_orders)}
                  hint={`${formatNumber(k.units_sold)} units · ${k.customers} customers`} change={change.total_orders}
                  chart={<Sparkline data={trend} dataKey="orders" color="#3b82f6" type="bar" />}
                  onClick={() => navigate('/orders')} />
                <KpiCard color="cyan" icon={<IconRupee />} label="Total Revenue"
                  value={formatMoney(k.total_revenue, cur, { compact: k.total_revenue >= 1e7 })}
                  hint={`Avg order ${formatMoney(k.avg_order_value, cur)}`} change={change.total_revenue}
                  chart={<Sparkline data={trend} dataKey="revenue" color="#0891b2" />} />
                <KpiCard color="red" icon={<IconClock />} label="Delayed Orders" value={formatNumber(k.delayed_orders)}
                  hint={`${k.delayed_pct}% of orders · SLA ${data.sla_days} days`} change={change.delayed_orders} goodWhenUp={false}
                  chart={<Sparkline data={trend} dataKey="delayed" color="#ef4444" type="bar" />}
                  onClick={() => navigate('/orders?delayed=1')} />
                <KpiCard color="yellow" icon={<IconTruck />} label="Avg Delivery Time"
                  value={k.avg_delivery_days != null ? `${k.avg_delivery_days} days` : '—'}
                  hint="Shipped orders only" change={change.avg_delivery_days} goodWhenUp={false}
                  chart={<Sparkline data={trend.filter((t) => t.avg_delivery_days != null)} dataKey="avg_delivery_days" color="#d97706" />} />
              </>
            )}
          </div>

          {!isLoading && k?.total_orders === 0 ? (
            <Card>
              {activeFilterCount(f) > 0 ? (
                <EmptyState title="No orders match these filters">
                  Your filters are hiding all the data.{' '}
                  <button className="btn primary sm" onClick={() => dispatch(resetFilters())}>Clear filters</button>
                </EmptyState>
              ) : (
                <EmptyState title="No data yet">Go to the Data page to upload files or load the demo dataset.</EmptyState>
              )}
            </Card>
          ) : (
            <div className="grid-3col">
              {/* ---------- Revenue trend ---------- */}
              <Card className="span-2" title="Revenue trend"
                subtitle="Bars = orders, line = revenue · click a point to zoom into that period"
                actions={<>
                  <Segmented label="View" options={VIEWS} value={view} onChange={(v) => dispatch(setMetric(v))} />
                  <Segmented label="Granularity" options={GRANULARITY} value={f.granularity} onChange={(v) => dispatch(setGranularity(v))} />
                </>}>
                {isLoading ? <Skeleton height={300} /> : trend.length ? (
                  <RevenueTrendChart data={trend} view={view} currency={cur} granularity={gran}
                    onPointClick={(p) => dispatch(setDateRange({ startDate: p.period, endDate: periodEnd(p.period, gran) }))} />
                ) : <EmptyState>No dated orders.</EmptyState>}
              </Card>

              {/* ---------- Category-wise revenue ---------- */}
              <Card title="Category-wise revenue" subtitle="Click a slice or name to drill down"
                actions={<Segmented label="Share by" options={SHARE} value={shareMetric} onChange={setShareMetric} />}>
                {isLoading ? <Skeleton height={300} /> : (
                  <CategoryDonut data={data.category_revenue} metric={shareMetric} currency={cur}
                    selected={f.categories} onSliceClick={setDrillCategory} />
                )}
              </Card>

              {/* ---------- Delivery performance ---------- */}
              <Card className="span-2" title="Delivery performance"
                subtitle="Orders per period by delivery outcome · click a status to filter the dashboard">
                {isLoading ? <Skeleton height={260} /> : (
                  <>
                    <div className="status-row">
                      {data.delivery_performance.map((d) => (
                        <button key={d.status} className={`status-chip ${f.statuses.includes(d.status) ? 'on' : ''}`}
                          onClick={() => dispatch(toggleStatus(d.status))} aria-pressed={f.statuses.includes(d.status)}>
                          <StatusBadge status={d.status} />
                          <strong>{d.orders}</strong>
                          <span className="muted tiny">{d.share}%{d.avg_delivery_days != null ? ` · ${d.avg_delivery_days}d avg` : ''}</span>
                        </button>
                      ))}
                    </div>
                    <DeliveryStackedChart data={trend} granularity={gran} onBarClick={(s) => dispatch(toggleStatus(s))} />
                  </>
                )}
              </Card>

              {/* ---------- Delivery time distribution ---------- */}
              <Card title="Delivery time" subtitle={`Red = slower than the ${data?.sla_days ?? 5}-day SLA`}>
                {isLoading ? <Skeleton height={220} /> : data.delivery_days_distribution.length
                  ? <DeliveryDaysChart data={data.delivery_days_distribution} sla={data.sla_days} />
                  : <EmptyState>No shipped orders.</EmptyState>}
              </Card>

              {/* ---------- Top customers / products ---------- */}
              <Card title="Top customers" subtitle="By revenue">
                {isLoading ? <Skeleton height={200} /> : (
                  <ol className="rank-list">
                    {data.top_customers.map((c, i) => (
                      <li key={c.customer_id}>
                        <span className="avatar" style={{ background: `hsl(${(i * 67 + 220) % 360} 80% 93%)` }}>{c.customer_name?.[0] ?? '?'}</span>
                        <div className="rank-main"><strong>{c.customer_name}</strong><span className="muted tiny">{c.orders} orders · {c.units} units</span></div>
                        <span className="rank-val">{formatMoney(c.revenue, cur, { compact: true })}</span>
                      </li>
                    ))}
                  </ol>
                )}
              </Card>

              <Card title="Top products" subtitle="By revenue">
                {isLoading ? <Skeleton height={200} /> : (
                  <ol className="rank-list">
                    {data.top_products.map((p, i) => (
                      <li key={p.product_id}>
                        <span className="rank-no">{i + 1}</span>
                        <div className="rank-main"><strong>{p.product_name}</strong><span className="muted tiny">{p.category} · {p.units} units</span></div>
                        <span className="rank-val">{formatMoney(p.revenue, cur, { compact: true })}</span>
                      </li>
                    ))}
                  </ol>
                )}
              </Card>

              {/* ---------- Data quality ---------- */}
              <Card title="Data quality" subtitle="Problems found while cleaning the files"
                actions={<span className={`kpi-icon sm ${issues.length ? 'warn' : 'ok'}`}><IconShield /></span>}>
                {!quality ? <Skeleton height={200} /> : issues.length === 0 ? (
                  <EmptyState title="All clean">No missing or inconsistent values in {quality.totals.orders} orders.</EmptyState>
                ) : (
                  <ul className="quality-list">
                    {issues.map((c) => (
                      <li key={c.key}>
                        <span className="q-count">{c.count}</span>
                        <div><strong>{c.label}</strong><span className="muted tiny">{c.handling}</span></div>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            </div>
          )}
        </>
      )}

      {drillCategory && <CategoryDrilldown category={drillCategory} onClose={() => setDrillCategory(null)} />}
    </div>
  )
}
