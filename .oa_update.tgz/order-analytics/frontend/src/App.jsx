import { NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { IconDashboard, IconOrders, IconUpload } from './components/icons'
import Dashboard from './pages/Dashboard'
import Orders from './pages/Orders'
import DataUpload from './pages/DataUpload'

const NAV = [
  { to: '/', label: 'Dashboard', icon: IconDashboard, end: true },
  { to: '/orders', label: 'Orders', icon: IconOrders },
  { to: '/data', label: 'Data upload', icon: IconUpload },
]

export default function App() {
  const { pathname } = useLocation()
  const current = NAV.find((n) => (n.end ? pathname === n.to : pathname.startsWith(n.to)))?.label ?? 'Dashboard'
  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="brand">
          <span className="logo" aria-hidden>
            <svg viewBox="0 0 32 32" width="30" height="30"><rect width="32" height="32" rx="9" fill="#4f46e5" />
              <path d="M8 22V14M14 22V9M20 22v-6M26 22V11" stroke="white" strokeWidth="3" strokeLinecap="round" /></svg>
          </span>
          <span>Order Analytics</span>
        </div>
        <div className="user-card">
          <span className="avatar lg">OA</span>
          <div><strong>Operations</strong><span className="muted tiny">Analytics workspace</span></div>
        </div>
        <nav>
          <span className="nav-title">Menu</span>
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <Icon width={18} height={18} /> <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <span className="tiny muted">Stack</span>
          <span className="tiny">FastAPI · MongoDB · React · Redux</span>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <div className="crumbs"><span className="muted">Analytics</span><span className="muted">/</span><strong>{current}</strong></div>
          <span className="muted small topbar-date">{today}</span>
        </header>
        <main className="content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/data" element={<DataUpload />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
