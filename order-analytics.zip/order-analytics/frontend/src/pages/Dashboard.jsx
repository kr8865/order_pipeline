import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import FilterBar from '../components/FilterBar'
import { CategoryDrilldown } from '../components/Drilldowns'
import { CategoryChart, DeliveryDaysChart, DeliveryStatusChart, RevenueTrendChart } from '../components/charts/Charts'
import { Card, EmptyState, ErrorState, KpiCard, Segmented, Skeleton } from '../components/ui'
import { errorMessage, filterParams, useGetSummaryQuery } from '../services/api'
import { selectFilters, setDateRange, setGranularity, setMetric, setStatuses, toggleStatus } from '../features/filters/filtersSlice'
import { formatMoney, formatNumber, periodEnd } from '../utils/format'

const METRICS = [{ value: 'revenue', label: 'Revenue' }, { value: 'orders', label: 'Orders' }]
const GRANULARITY = [
  { value: 'auto', label: 'Auto' }, { value: 'day', label: 'Day' }, { value: 'week', label: 'Week' }, { value: 'month', label: 'Month' },
]

export default function Dashboard() {
  const f = useSelector(selectFilters)
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [drillCategory, setDrillCategory] = useState(null)
  const invalidRange = f.startDate && f.endDate && f.startDate > f.endDate
  const { data, error, isLoading, isFetching, refetch } = useGetSummaryQuery(
    filterParams(f, { granularity: f.granularity }), { skip: invalidRange },
  )
  const cur = data?.currency?.code || f.currency
  const k = data?.kpis
  const gran = data?.filters?.granularity || 'day'

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Dashboard</h1>
          <p className="muted">Orders, revenue and delivery performance{data?.currency?.source === 'fallback' &&
            <span className="pill warn" title="Live FX API unreachable — using approximate rates">approx. FX rates</span>}</p>
        </div>
        {isFetching && !isLoading && <span className="muted small"><span className="spinner sm" /> Updating…</span>}
      </div>

      <FilterBar />

      {error ? <ErrorState message={errorMessage(error)} onRetry={refetch} /> : (
        <>
          <div className={`kpi-grid ${isFetching ? 'dim' : ''}`}>
            {isLoading ? [1, 2, 3, 4].map((i) => <Skeleton key={i} height={104} />) : (
              <>
                <KpiCard label="Total Orders" value={formatNumber(k.total_orders)}
                  hint={`${formatNumber(k.units_sold)} units · ${k.customers} customers`} onClick={() => navigate('/orders')} />
                <KpiCard label="Total Revenue" tone="primary" value={formatMoney(k.total_revenue, cur)}
                  hint={`Avg order ${formatMoney(k.avg_order_value, cur)}`} />
                <KpiCard label="Delayed Orders" tone={k.delayed_orders ? 'bad' : 'ok'} value={formatNumber(k.delayed_orders)}
                  hint={`${k.delayed_pct}% of orders · SLA ${data.sla_days} days`} onClick={() => navigate('/orders?delayed=1')} />
                <KpiCard label="Avg Delivery Time" value={k.avg_delivery_days != null ? `${k.avg_delivery_days} days` : '—'}
                  hint="Shipped orders only" />
              </>
            )}
          </div>

          {!isLoading && k?.total_orders === 0 ? (
            <Card><EmptyState title="No orders match these filters">Try widening the date range or clearing filters.</EmptyState></Card>
          ) : (
            <div className="grid-2">
              <Card className="span-2" title={`${f.metric === 'revenue' ? 'Revenue' : 'Orders'} trend`}
                subtitle="Click a point to zoom into that period"
                actions={<>
                  <Segmented label="Metric" options={METRICS} value={f.metric} onChange={(v) => dispatch(setMetric(v))} />
                  <Segmented label="Granularity" options={GRANULARITY} value={f.granularity} onChange={(v) => dispatch(setGranularity(v))} />
                </>}>
                {isLoading ? <Skeleton height={280} /> : data.revenue_trend.length ? (
                  <RevenueTrendChart data={data.revenue_trend} metric={f.metric} currency={cur} granularity={gran}
                    onPointClick={(p) => dispatch(setDateRange({ startDate: p.period, endDate: periodEnd(p.period, gran) }))} />
                ) : <EmptyState>No dated orders.</EmptyState>}
              </Card>

              <Card title="Category-wise revenue" subtitle="Click a bar to drill down into products"
                actions={<Segmented label="Metric" options={METRICS} value={f.metric} onChange={(v) => dispatch(setMetric(v))} />}>
                {isLoading ? <Skeleton height={220} /> : (
                  <CategoryChart data={data.category_revenue} metric={f.metric} currency={cur} selected={f.categories}
                    onBarClick={setDrillCategory} />
                )}
              </Card>

              <Card title="Delivery performance" subtitle="Click a slice to filter by status"
                actions={f.statuses.length > 0 && <button className="btn ghost sm" onClick={() => dispatch(setStatuses([]))}>Show all</button>}>
                {isLoading ? <Skeleton height={220} /> : (
                  <>
                    <DeliveryStatusChart data={data.delivery_performance} onSliceClick={(s) => dispatch(toggleStatus(s))} />
                    <table className="table compact">
                      <thead><tr><th>Status</th><th className="num">Orders</th><th className="num">Avg days</th><th className="num">Revenue</th></tr></thead>
                      <tbody>{data.delivery_performance.map((d) => (
                        <tr key={d.status}><td>{d.status}</td><td className="num">{d.orders}</td>
                          <td className="num">{d.avg_delivery_days ?? '—'}</td><td className="num">{formatMoney(d.revenue, cur, { compact: true })}</td></tr>
                      ))}</tbody>
                    </table>
                  </>
                )}
              </Card>

              {!isLoading && data.delivery_days_distribution.length > 0 && (
                <Card className="span-2" title="Delivery time distribution" subtitle={`Orders by days to deliver — red bars exceed the ${data.sla_days}-day SLA`}>
                  <DeliveryDaysChart data={data.delivery_days_distribution} sla={data.sla_days} />
                </Card>
              )}
            </div>
          )}
        </>
      )}

      {drillCategory && <CategoryDrilldown category={drillCategory} onClose={() => setDrillCategory(null)} />}
    </div>
  )
}
