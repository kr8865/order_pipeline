import { createSlice } from '@reduxjs/toolkit'

const STORAGE_KEY = 'order-analytics:filters'

const defaults = {
  startDate: '',
  endDate: '',
  categories: [],
  statuses: [],
  currency: 'INR',
  metric: 'revenue', // 'revenue' | 'orders'  -> chart toggle
  granularity: 'auto',
}

function loadInitial() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')
    return saved ? { ...defaults, ...saved } : defaults
  } catch {
    return defaults
  }
}

const toggleIn = (list, value) => (list.includes(value) ? list.filter((v) => v !== value) : [...list, value])

const filtersSlice = createSlice({
  name: 'filters',
  initialState: loadInitial(),
  reducers: {
    setDateRange(state, { payload }) {
      state.startDate = payload.startDate ?? state.startDate
      state.endDate = payload.endDate ?? state.endDate
    },
    toggleCategory(state, { payload }) { state.categories = toggleIn(state.categories, payload) },
    setCategories(state, { payload }) { state.categories = payload },
    toggleStatus(state, { payload }) { state.statuses = toggleIn(state.statuses, payload) },
    setStatuses(state, { payload }) { state.statuses = payload },
    setCurrency(state, { payload }) { state.currency = payload },
    setMetric(state, { payload }) { state.metric = payload },
    setGranularity(state, { payload }) { state.granularity = payload },
    resetFilters(state) {
      return { ...defaults, currency: state.currency, metric: state.metric }
    },
  },
})

export const {
  setDateRange, toggleCategory, setCategories, toggleStatus, setStatuses, setCurrency, setMetric,
  setGranularity, resetFilters,
} = filtersSlice.actions

export const selectFilters = (s) => s.filters
export const activeFilterCount = (f) =>
  (f.startDate ? 1 : 0) + (f.endDate ? 1 : 0) + f.categories.length + f.statuses.length

export function persistFilters(store) {
  let last
  store.subscribe(() => {
    const f = store.getState().filters
    if (f !== last) {
      last = f
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(f)) } catch { /* storage unavailable */ }
    }
  })
}

export default filtersSlice.reducer
