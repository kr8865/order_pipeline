import { useDispatch, useSelector } from 'react-redux'
import { useGetCurrenciesQuery, useGetFiltersQuery } from '../services/api'
import {
  activeFilterCount, resetFilters, selectFilters, setCurrency, setDateRange, toggleCategory, toggleStatus,
} from '../features/filters/filtersSlice'
import { STATUS_COLORS } from '../utils/format'

function shift(iso, days) {
  const d = new Date(iso + 'T00:00:00')
  d.setDate(d.getDate() - days)
  return d.toISOString().slice(0, 10)
}

export default function FilterBar({ showCurrency = true }) {
  const dispatch = useDispatch()
  const f = useSelector(selectFilters)
  const { data: opts, isLoading } = useGetFiltersQuery()
  const { data: currencies } = useGetCurrenciesQuery(undefined, { skip: !showCurrency })
  const count = activeFilterCount(f)
  const invalidRange = f.startDate && f.endDate && f.startDate > f.endDate

  const preset = (days) => {
    if (!opts?.max_date) return
    dispatch(setDateRange({ startDate: days ? shift(opts.max_date, days - 1) : '', endDate: days ? opts.max_date : '' }))
  }

  return (
    <div className="filter-bar card">
      <div className="filter-group">
        <label className="filter-label">Date range</label>
        <div className="row wrap gap-s">
          <input type="date" value={f.startDate} min={opts?.min_date || undefined} max={f.endDate || opts?.max_date || undefined}
            onChange={(e) => dispatch(setDateRange({ startDate: e.target.value }))} aria-label="Start date" />
          <span className="muted">→</span>
          <input type="date" value={f.endDate} min={f.startDate || opts?.min_date || undefined} max={opts?.max_date || undefined}
            onChange={(e) => dispatch(setDateRange({ endDate: e.target.value }))} aria-label="End date" />
          <div className="chips">
            <button className="chip" onClick={() => preset(0)}>All</button>
            <button className="chip" onClick={() => preset(30)}>Last 30d</button>
            <button className="chip" onClick={() => preset(90)}>Last 90d</button>
          </div>
        </div>
        {invalidRange && <span className="field-error">Start date is after end date</span>}
        {opts?.min_date && <span className="muted tiny">Data available {opts.min_date} → {opts.max_date}</span>}
      </div>

      <div className="filter-group">
        <label className="filter-label">Category</label>
        <div className="chips">
          {isLoading && <span className="muted small">Loading…</span>}
          {opts?.categories.map((c) => (
            <button key={c} className={`chip ${f.categories.includes(c) ? 'on' : ''}`}
              aria-pressed={f.categories.includes(c)} onClick={() => dispatch(toggleCategory(c))}>{c}</button>
          ))}
        </div>
      </div>

      <div className="filter-group">
        <label className="filter-label">Delivery status</label>
        <div className="chips">
          {opts?.statuses.map((s) => (
            <button key={s} className={`chip ${f.statuses.includes(s) ? 'on' : ''}`}
              aria-pressed={f.statuses.includes(s)} onClick={() => dispatch(toggleStatus(s))}>
              <span className="dot" style={{ background: STATUS_COLORS[s] || '#64748b' }} />{s}
            </button>
          ))}
        </div>
      </div>

      <div className="filter-group filter-end">
        {showCurrency && (
          <>
            <label className="filter-label" htmlFor="currency">Currency</label>
            <select id="currency" value={f.currency} onChange={(e) => dispatch(setCurrency(e.target.value))}>
              <option value="INR">INR – Indian rupee</option>
              {currencies?.filter((c) => c.code !== 'INR').map((c) => (
                <option key={c.code} value={c.code}>{c.code} – {c.name}</option>
              ))}
            </select>
          </>
        )}
        <button className="btn ghost" disabled={!count} onClick={() => dispatch(resetFilters())}>
          Clear filters{count ? ` (${count})` : ''}
        </button>
      </div>
    </div>
  )
}
