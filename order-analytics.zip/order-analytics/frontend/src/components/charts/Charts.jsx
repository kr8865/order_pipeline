/* Chart components (Recharts). Each is reusable and receives data + callbacks via props. */
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { formatMoney, formatNumber, formatPeriod, SERIES, STATUS_COLORS } from '../../utils/format'

const axis = { fontSize: 12, fill: '#64748b' }

function valueFormatter(metric, currency, compact) {
  return (v) => (metric === 'revenue' ? formatMoney(v, currency, { compact }) : formatNumber(v))
}

export function RevenueTrendChart({ data, metric, currency, granularity, onPointClick }) {
  const fmt = valueFormatter(metric, currency, true)
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}
        onClick={(e) => e?.activePayload && onPointClick?.(e.activePayload[0].payload)}
        style={{ cursor: onPointClick ? 'pointer' : 'default' }}>
        <defs>
          <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES[0]} stopOpacity={0.35} />
            <stop offset="100%" stopColor={SERIES[0]} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis dataKey="period" tick={axis} tickFormatter={(v) => formatPeriod(v, granularity)} minTickGap={16} />
        <YAxis tick={axis} tickFormatter={fmt} width={72} allowDecimals={metric === 'revenue'} />
        <Tooltip labelFormatter={(v) => `${granularity === 'day' ? '' : granularity + ' of '}${formatPeriod(v, 'day')}`}
          formatter={(v) => [valueFormatter(metric, currency, false)(v), metric === 'revenue' ? 'Revenue' : 'Orders']} />
        <Area type="monotone" dataKey={metric} stroke={SERIES[0]} strokeWidth={2} fill="url(#trendFill)"
          dot={data.length < 40 ? { r: 3 } : false} activeDot={{ r: 6 }} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

export function CategoryChart({ data, metric, currency, selected = [], onBarClick }) {
  const key = metric === 'revenue' ? 'revenue' : 'orders'
  const fmt = valueFormatter(metric, currency, true)
  const height = Math.max(200, data.length * 44)
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 24, left: 8, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
        <XAxis type="number" tick={axis} tickFormatter={fmt} />
        <YAxis type="category" dataKey="category" tick={axis} width={110} />
        <Tooltip formatter={(v, _n, p) => [valueFormatter(metric, currency, false)(v),
          `${metric === 'revenue' ? 'Revenue' : 'Orders'} (${p.payload.share}% of revenue)`]} cursor={{ fill: '#f1f5f9' }} />
        <Bar dataKey={key} radius={[0, 6, 6, 0]} onClick={(d) => onBarClick?.(d.category)} style={{ cursor: 'pointer' }}>
          {data.map((d, i) => (
            <Cell key={d.category} fill={SERIES[i % SERIES.length]}
              fillOpacity={selected.length && !selected.includes(d.category) ? 0.35 : 1} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}

export function DeliveryStatusChart({ data, onSliceClick }) {
  return (
    <ResponsiveContainer width="100%" height={240}>
      <PieChart>
        <Pie data={data} dataKey="orders" nameKey="status" innerRadius={55} outerRadius={90} paddingAngle={2}
          onClick={(d) => onSliceClick?.(d.status)} style={{ cursor: 'pointer' }}>
          {data.map((d) => <Cell key={d.status} fill={STATUS_COLORS[d.status] || '#64748b'} />)}
        </Pie>
        <Tooltip formatter={(v, n, p) => [`${v} orders${p.payload.avg_delivery_days != null ? ` · avg ${p.payload.avg_delivery_days} days` : ''}`, n]} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  )
}

export function DeliveryDaysChart({ data, sla }) {
  return (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={data} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis dataKey="days" tick={axis} label={{ value: 'days to deliver', position: 'insideBottom', offset: -2, fontSize: 11, fill: '#94a3b8' }} height={36} />
        <YAxis tick={axis} allowDecimals={false} width={36} />
        <Tooltip formatter={(v) => [`${v} orders`, 'Orders']} labelFormatter={(d) => `${d} day(s)`} />
        <ReferenceLine x={sla} stroke="#ef4444" strokeDasharray="4 4" label={{ value: `SLA ${sla}d`, fill: '#ef4444', fontSize: 11, position: 'top' }} />
        <Bar dataKey="orders" radius={[6, 6, 0, 0]}>
          {data.map((d) => <Cell key={d.days} fill={d.late ? '#ef4444' : '#10b981'} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
